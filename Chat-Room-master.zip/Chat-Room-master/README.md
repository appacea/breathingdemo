# Chat-Room
- A 1v1 Video Chatting application using Python3 sockets.

- To Host:- 
```
python3 serverMedia.py
```

- To Connect:-
```
python3 clientMedia.py
```

Please Go through [this link](https://medium.com/@adityakumar_365/video-conferencing-using-sockets-in-python-3-b4a346416bca) for further details.
